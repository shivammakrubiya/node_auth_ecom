const User = require("../models/user")
const cryptojs = require('crypto-js/aes')

module.exports = {
    addUser : async (req, res) => {
    try {

        const {username, email, password} = req.body

        const encryptPassword = cryptojs.encrypt(password, process.env.SECRET_KEY)
        console.log(encryptPassword);

        let object4UserAdd = {
            username : username,
            email : email 
        }
        if(!username || !email || !password){
            return res.status(400).send({success : false, message : "All feild is required"})
        }

        const isUserExist = await User.findOne({email : email})

        if(isUserExist){
            return res.status(400).send({message : false, message : "Email  is already exist"})
        }

        const userData = await User.create(req.body)
        res.status(201).send({success : true, data : userData})
    } catch (error) {
        res.send({success : false, message : error.message})
    }
    }
}