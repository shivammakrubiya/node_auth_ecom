const express = require("express");
const { addUser } = require("../controller/user.controller");
const routes = express.Router();

routes.post('/add', addUser);

module.exports = {routes}